<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mahasiswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelvr.net/npm/boostrap@5.3.0/dist/css/boostrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-4 mb-4">Tambah mahasiswa</h1>
        <form method="POST" action="aksi_simpan.php">
            <div class="mb-3">
                <label for="nim" class="from-label">NIM</label>
                <input type="text" class="from-control" id="nim" name="nim" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="from-label">Nama</label>
                <input type="text" class="from-control" id="nama" name="nama" required>
            </div>
            < class="mb-3">
                <label for="jenis_kelamin" class="from-label">Jenis Kelamin</label>
                <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
                <div class="mb-3">
                <label for="nim" class="from-label">NIM</label>
                <input type="text" class="from-control" id="nim" name="nim" required>
            </div>
            <div class="mb-3">
                <label for="jurusan" class="from-label">Jurusan</label>
                <select class="form-label" id="jurusan" name="jurusan" required>
                    <option value="Informatika">Informatika</option>
                    <option value="Sistem Informasi">Sistem Informasi</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="alamat" class="from-label">Alamat</label>
                <textarea class="form-control" name="alamat" id="alamat" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>